document.addEventListener('DOMContentLoaded', function () {
    const chatbotIcon = document.getElementById('chatbot-icon');
    const chatbotWindow = document.getElementById('chatbot-window');
    const closeButton = document.getElementById('close-button');

    // Show the chatbot window when the chatbot icon is clicked
    chatbotIcon.addEventListener('click', function () {
        chatbotWindow.style.display = 'block';
    });

    // Close the chatbot window when the close button is clicked
    closeButton.addEventListener('click', function () {
        chatbotWindow.style.display = 'none';
    });
});
